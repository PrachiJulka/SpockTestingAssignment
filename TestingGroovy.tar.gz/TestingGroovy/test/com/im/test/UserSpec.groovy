package com.im.test

import spock.lang.Specification

class UserSpec extends Specification {

           def "First test"(){
               expect:
               true
           }




























}
