package com.im.test

class SaleException extends Exception {
    SaleException(String s){
        super(s)
    }
}
