package com.im.test


class Inventory {
    List<Product>allProducts

}
